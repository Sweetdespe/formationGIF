package Shop.model.bean;

public class Product {
	
	private float price;
    private String url;
    private String title;

	public Product( String p_title, String p_url, float p_price) {
		super();
		
		this.url = p_url;
		this.title = p_title;
		this.price = p_price;
	}
	
    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String toString() {		
		String data = "{";
	
		data += " \"title\": \""+this.title+"\", ";
		data += " \"url\": \""	+this.url+"\", ";
		data += " \"price\": \""+this.price+"\"";
		
		data += "}";
		
		return data;
	}
}
