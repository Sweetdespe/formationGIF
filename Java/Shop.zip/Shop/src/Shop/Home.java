package Shop;

import java.io.FileReader;
import java.io.File;
import java.io.IOException;

/* affichage JSON par readallbytes */
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Shop.model.bean.Product;


public class Home extends HttpServlet {

	public Home() {
		super();
		
		// TODO Auto-generated constructor stub
	}
	
//	Product pyjama = new Product( "Pyjama", "..",10 );
	
	public void doGet(
	
			HttpServletRequest p_request,
			HttpServletResponse p_response

	) throws ServletException, IOException 
	{
		
		ArrayList<Product> catalog = new ArrayList<Product>();
		
		catalog.add( new Product("Assiettes", "https://tinyurl.com/ycma3trs", (float)6) );
		catalog.add( new Product("Verre", "https://tinyurl.com/yal7wuvx", (float)3.55) );
		catalog.add( new Product("Tasses", "https://tinyurl.com/y7qrj4jt", (float)3) );
		catalog.add( new Product("Bols", "https://tinyurl.com/ydh8paqw", (float)6) );
		catalog.add( new Product("Ramequin", "https://tinyurl.com/ycerpmr4", (float)1) );

		
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setCharacterEncoding("utf-8");
		
		
		p_request.setAttribute("catalog", catalog );
		
		
		this.getServletContext().getRequestDispatcher("/Home.jsp")
								.forward(p_request, p_response);
	}
/*	
	{
		p_response.setHeader("Access-Control-Allow-Origin", "*");
		p_response.setCharacterEncoding("UTF-8");
/*		
		String data = this.readFile(
			p_request.getServletContext().getRealPath("products.json")
			
		);
*/
//		PrintWriter out = p_response.getWriter();
		
//		out.println(data);
		
//	}

	
	/* affichage JSON par readallbytes */
//	protected String readFile(String path) throws IOException {
		
	/*
		File data = new File(path);
		FileReader reader = new FileReader(data);
	*/

	/* affichage JSON par readallbytes */
//		String output = "";
	
/*		
		int character = 0;
		do {
			character = reader.read();
			
			if( character == -1 )
				break;
			
			output += (char)character;
		}while( character != -1 );
		
		reader.close();
		 
		return output;

*/
	
	/* affichage JSON par readallbytes */
/*	
		Path newpath = Paths.get(this.getServletContext().getRealPath("products.json"));
		
	    try {
	    
	      byte[] contenufichier = Files.readAllBytes(newpath);

	      output = new String(contenufichier, "UTF-8");
	      return output;
	      
	    } catch (IOException e) {
	      System.out.println(e);
	    }
	    
      return output;
	
	}
*/	
}
