import { AlphaPipe } from './alpha.pipe';

describe('AlphaPipe', () => {
  it('create an instance', () => {
    const pipe = new AlphaPipe();
    expect(pipe).toBeTruthy();
  });
});
