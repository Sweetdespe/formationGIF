
export const environment = {
  production: false, 
  getCatalogURL: "http://localhost:8080/shop/catalog",
  postCatalogURL: "http://localhost:8080/shop/catalog/add",
  delCatalogURL: "http://localhost:8080/shop/catalog/rem"
};

